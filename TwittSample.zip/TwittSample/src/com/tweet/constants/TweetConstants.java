/**
 * Here are the info of the keys constants, easy to access the application.
 */

package com.tweet.constants;

public final class TweetConstants {
	public final static String ACCESS_TOKEN = "731979426812944384-YS55JU2dHFqR2DxG3gch2TwgZyOmzux";
	public final static String ACCESS_TOKEN_SECRET = "DKuxZZ2KoQpfhP6TceUUqcy1Gmj6wrZXICcm8m47lYMvC";
	public final static String CONSUMER_KEY = "9f1wPCHk7Ww15RBXfctDx4kMu ";
	public final static String CONSUMER_SECRET="J0quZRmIpKlbb3XGaqTNDJ0W6dArmjzrHmmt5UCTAv2PwvHtTo";
	public final static String SCREEN_NAME = "Salesforce";
	public final static String COUNT = "10";

}
